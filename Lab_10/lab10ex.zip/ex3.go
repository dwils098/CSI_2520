package main

import (
	"fmt"
	"strings"
)

func main() {
	// Count the number of consonants in a string: a, e, i, o, u
	text := "The School of Electrical Engineering and Computer Science was formed in 1997 by the merger of the Department of Computer Science and of the Department of Electrical and Computer Engineering. The School of EECS is the University of Ottawa's centre for research and teaching in all areas related to computing, computers and communications. This interdisciplinary school combines four cutting-edge programs: electrical engineering, software engineering, computer engineering and computer science."

	// Version A
	var cntA, cntE, cntI, cntO, cntU int
	for _, charVal := range text {
		switch {
		case charVal == 'a' || charVal == 'A':
			cntA++
		case charVal == 'e' || charVal == 'E':
			cntE++
		case charVal == 'i' || charVal == 'I':
			cntI++
		case charVal == 'o' || charVal == 'O':
			cntO++
		case charVal == 'u' || charVal == 'U':
			cntU++
		}
	}
	fmt.Printf("a/e/i/o/u: %d/%d/%d/%d/%d\n", cntA, cntE, cntI, cntO, cntU)

	// Version B
	cntA, cntE, cntI, cntO, cntU = 0, 0, 0, 0, 0
	for _, charVal := range text {
		switch charVal {
		case 'a', 'A':
			cntA++
		case 'e', 'E':
			cntE++
		case 'i', 'I':
			cntI++
		case 'o', 'O':
			cntO++
		case 'u', 'U':
			cntU++
		}
	}
	fmt.Printf("a/e/i/o/u: %d/%d/%d/%d/%d\n", cntA, cntE, cntI, cntO, cntU)

	// strings package
	fmt.Printf("%d number of a\n",
		strings.Count(text, "a")+strings.Count(text, "A"))
	fmt.Printf("%d number of e\n",
		strings.Count(text, "e")+strings.Count(text, "E"))
	fmt.Printf("%d number of i\n",
		strings.Count(text, "i")+strings.Count(text, "I"))
	fmt.Printf("%d number of o\n",
		strings.Count(text, "o")+strings.Count(text, "O"))
	fmt.Printf("%d number of u\n",
		strings.Count(text, "u")+strings.Count(text, "U"))
}
